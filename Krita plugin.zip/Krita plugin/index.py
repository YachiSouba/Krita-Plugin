print("Hello, World!") 
print("Testing Hackatime")